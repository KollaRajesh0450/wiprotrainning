export interface Student {
  id: number;
  name: string;
  city: string;
  totalMarks: number;
}
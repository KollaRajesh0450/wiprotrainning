import { Routes } from '@angular/router';
import { StudentList } from './student-list/student-list';
import { StudentFormComponent } from './student-form/student-form';


export const routes: Routes = [
    { path: '', redirectTo: '/students', pathMatch: 'full' },
    { path: 'students', component: StudentList },
  
  // When the URL is '.../students/add', show the form component
  { path: 'students/add', component: StudentFormComponent },
  
  // When the URL is '.../students/edit/1' (or any id), also show the form component
  // The ':id' is a placeholder for the student's ID
  { path: 'students/edit/:id', component: StudentFormComponent }

];

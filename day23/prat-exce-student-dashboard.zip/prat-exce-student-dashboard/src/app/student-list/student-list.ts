import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student';
import { CommonModule } from '@angular/common';
import { Student } from '../student.model';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './student-list.html',
  styleUrl: './student-list.css'
})
export class StudentList implements OnInit{
  students: Student[] = [];

  // We inject the StudentService in the constructor
  constructor(private studentService: StudentService) {}

  // ngOnInit is the perfect place for initial data fetching
  ngOnInit(): void {
    this.students = this.studentService.getStudents();
  }
  onDelete(id: number): void {
    // Optional: Ask for confirmation
    if (confirm('Are you sure you want to delete this student?')) {
      this.studentService.deleteStudent(id);
      // Refresh the list from the service to show the change
      this.students = this.studentService.getStudents();
    }
  }

}

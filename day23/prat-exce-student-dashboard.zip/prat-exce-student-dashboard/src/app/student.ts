// src/app/student.service.ts
import { Injectable } from '@angular/core';
import { Student } from './student.model';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private students: Student[] = [
    { id: 1, name: 'rajesh', city:"hyderabad", totalMarks:90 },
    { id: 2, name: 'suresh',city: "mumbai",  totalMarks:89},
    { id: 3, name: 'ramesh',city: "delhi",  totalMarks:88},
    { id: 4, name: 'raju',city: "pune",  totalMarks:87}

  ];

  private nextId = 4;

  // METHOD 1: Gets the ENTIRE list of students.
  getStudents(): Student[] {
    return this.students;
  }

  // METHOD 2: Gets a SINGLE student by their ID.
  getStudentById(id: number): Student | undefined {
    return this.students.find(student => student.id === id);
  }

  // CREATE: Method to add a new student
  addStudent(student: Omit<Student, 'id'>): void {
    const newStudent: Student = {
        id: this.nextId,
        ...student
    };
    this.nextId++;
    this.students.push(newStudent);
  }

  // UPDATE: Method to update an existing student
   updateStudent(updatedStudent: Student): void {
    const index = this.students.findIndex(s => s.id === updatedStudent.id);
    if (index !== -1) {
        this.students[index] = updatedStudent;
    }
  }

  // DELETE: Method to remove a student
  deleteStudent(id: number): void {
    this.students = this.students.filter(student => student.id !== id);
  }

}
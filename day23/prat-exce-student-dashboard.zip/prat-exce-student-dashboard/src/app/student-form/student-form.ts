import { Component,OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StudentService } from '../student';
import { Student } from '../student.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({  
  selector: 'app-student-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './student-form.html',
  styleUrls: ['./student-form.css']
})
export class StudentFormComponent implements OnInit {
  // Use the full Student model to accommodate the id for updates
  student: Student = { id: 0, name: '', city: '', totalMarks: 0};
  isEditMode = false;

  constructor(
    private studentService: StudentService,
    private route: ActivatedRoute, // Injects the ActivatedRoute service
    private router: Router // Injects the Router for navigation
  ) {}

  ngOnInit(): void {
    // Check for an 'id' parameter in the URL
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.isEditMode = true;
      const studentId = +idParam; // The '+' converts the string 'id' to a number
      
      // Fetch the existing student from the service
      const existingStudent = this.studentService.getStudentById(studentId);
      if (existingStudent) {
        // If found, populate the form with their data
        this.student = { ...existingStudent };
      }
    }
  }

  onSubmit(): void {
    if (this.isEditMode) {
      // If we are in edit mode, call the update method
      this.studentService.updateStudent(this.student);
    } else {
      // Otherwise, call the add method
      this.studentService.addStudent(this.student);
    }
    // After submit, navigate back to the main student list
    this.router.navigate(['/students']);
  }
}
import { Component } from '@angular/core';

@Component({
  selector: 'app-student-details',
  imports: [],
  templateUrl: './student-details.html',
  styleUrl: './student-details.css'
})
export class StudentDetails {
  public students=[
    {"id": 1001,"name" : "rajesh","marks" : 90},
    {"id": 1002,"name" : "raju","marks" : 77},
    {"id": 1003,"name" : "ramesh","marks" : 89},
    {"id": 1004,"name" : "suresh","marks" : 60},
    {"id": 1005,"name" : "ravi","marks" : 70}
  ]
  constructor() {}
  
  ngOnInit(){}

}

import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { StudentDetails } from './student-details/student-details';
import { StudentMarks } from './student-marks/student-marks';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Pipe,PipeTransform } from '@angular/core';
import { Student } from './student';

@Component({
  selector: 'app-root',
  imports: [Student,StudentDetails,StudentMarks],
  templateUrl: './app.html',
  styleUrl: './app.css'
})

@NgModule({
  declarations: [
    AppComponent,   // Your main component
    StudentDetails, // Your student details component
    StudentMarks,   // Your student marks component
    NamePipe        // Your custom pipe
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
})

export class NamePipe implements PipeTransform {
      @Pipe({
          name:'namePipe',
          standalone: true
      })
  
    transform(value: string, defaultValue: string):string{
      if(value != ""){
        return value;
      } else {
        return defaultValue;
      }
    }
  }

export class App {
  protected readonly title = signal('httpobservbles_demo');  
}

export class AppComponent{

}

